If you want to run models 

Just start Ipython notebook and run cells that don't contain training part if you have weights to load.

Other wise run all cells.
